#!/bin/bash

echo "=== Тестирование system-info утилиты ==="
echo ""

# 1. Тест справки
echo "1. Тест справки (-h):"
system-info -h | head -10
echo ""

# 2. Тест пользователей
echo "2. Тест вывода пользователей (-u):"
system-info -u | head -5
echo ""

# 3. Тест процессов
echo "3. Тест вывода процессов (-p):"
system-info -p | head -5
echo ""

# 4. Тест с записью в домашнюю директорию
echo "4. Тест записи в домашнюю директорию:"
system-info -u -l ~/test_users.log 2>&1 | tail -2
ls -la ~/test_users.log 2>/dev/null && echo "Файл создан: ~/test_users.log"
echo ""

# 5. Тест с записью в /tmp
echo "5. Тест записи в /tmp:"
system-info -p -l /tmp/test_processes.log -e /tmp/test_errors.log 2>&1 | tail -2
ls -la /tmp/test_*.log 2>/dev/null
echo ""

# 6. Тест комбинации
echo "6. Тест комбинации (u+p):"
system-info -u -p | wc -l | awk '{print "Выведено строк:", $1}'
echo ""

# 7. Тест ошибок (недоступный путь)
echo "7. Тест ошибок (недоступный путь):"
system-info -u -l /root/test.log 2>&1 | head -2
echo ""

# 8. Тест длинных опций
echo "8. Тест длинных опций:"
system-info --users --log /tmp/long_test.log 2>&1 | tail -2
ls -la /tmp/long_test.log 2>/dev/null
echo ""

# 9. Очистка тестовых файлов
echo "9. Очистка тестовых файлов:"
rm -f ~/test_users.log /tmp/test_processes.log /tmp/test_errors.log /tmp/long_test.log /tmp/output.log /tmp/errors.log 2>/dev/null
echo "Тестовые файлы удалены"
echo ""
echo "=== Тестирование завершено ==="
