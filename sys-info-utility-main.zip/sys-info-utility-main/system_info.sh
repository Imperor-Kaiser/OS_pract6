#!/bin/bash

# Функция для вывода справки
show_help() {
    cat << EOF
Системная утилита для получения информации о системе

Использование: $(basename "$0") [ПАРАМЕТРЫ]

Параметры:
  -u, --users          Вывести список пользователей и их домашние директории
  -p, --processes      Вывести список запущенных процессов
  -l, --log PATH       Сохранить вывод в файл по указанному пути
  -e, --errors PATH    Сохранить ошибки (stderr) в файл по указанному пути
  -h, --help           Показать эту справку

Примеры:
  $(basename "$0") -u
  $(basename "$0") -p -l /var/log/system_info.log
  $(basename "$0") -u -e /var/log/errors.log
EOF
    exit 0
}

# Функция для проверки доступности пути
check_path_access() {
    local path="$1"
    local type="$2" # "file" или "dir"
    
    if [[ -z "$path" ]]; then
        return 1
    fi
    
    # Проверяем существование родительской директории для файла
    if [[ "$type" == "file" ]]; then
        local dir=$(dirname "$path")
        
        # Создаем директорию, если ее нет (если возможно)
        if [[ ! -d "$dir" ]] && [[ -w "$(dirname "$dir")" ]] 2>/dev/null; then
            mkdir -p "$dir" 2>/dev/null && return 0
        fi
        
        if [[ ! -d "$dir" ]]; then
            echo "Ошибка: Директория '$dir' не существует" >&2
            return 1
        fi
        
        # Проверяем возможность записи
        if [[ ! -w "$dir" ]]; then
            echo "Ошибка: Нет прав на запись в директорию '$dir'" >&2
            return 1
        fi
        
        # Пробуем создать тестовый файл
        if touch "$path.tmp" 2>/dev/null; then
            rm -f "$path.tmp"
            return 0
        else
            echo "Ошибка: Невозможно создать файл '$path'" >&2
            return 1
        fi
    fi
    
    return 0
}

# Функция для вывода списка пользователей
show_users() {
    echo "Список пользователей и их домашние директории:"
    echo "=============================================="
    
    # Более надежный способ получения пользователей
    if command -v getent >/dev/null 2>&1; then
        getent passwd | awk -F: '{if ($3 >= 1000 || $3 == 0) printf "%-20s %s\n", $1, $6}' | sort
    else
        # Fallback для систем без getent
        awk -F: '{if ($3 >= 1000 || $3 == 0) printf "%-20s %s\n", $1, $6}' /etc/passwd | sort
    fi
}

# Функция для вывода списка процессов
show_processes() {
    echo "Список запущенных процессов (отсортирован по PID):"
    echo "=================================================="
    
    # Более компактный формат вывода
    ps -eo pid,user,comm --sort=pid --no-headers | awk '{printf "PID: %-8s Пользователь: %-12s Команда: %s\n", $1, $2, $3}'
}

# Функция для обработки вывода
process_output() {
    {
        echo "=== Системная информация ==="
        echo "Дата и время: $(date)"
        echo "Хост: $(hostname)"
        echo "Пользователь: $(whoami)"
        echo ""
        
        if [[ "$SHOW_USERS" == true ]]; then
            show_users
            echo ""
        fi
        
        if [[ "$SHOW_PROCESSES" == true ]]; then
            show_processes
        fi
        
        echo ""
        echo "=== Конец отчета ==="
        echo "Сгенерировано утилитой: $(basename "$0")"
    }
}

# Основные переменные
LOG_FILE=""
ERROR_FILE=""
SHOW_USERS=false
SHOW_PROCESSES=false
EXECUTED=false

# Проверка наличия аргументов
if [[ $# -eq 0 ]]; then
    echo "Ошибка: Не указаны параметры. Используйте -h для справки." >&2
    echo "Пример: $(basename "$0") -u" >&2
    exit 1
fi

# Временные файлы для хранения вывода
TEMP_OUTPUT=$(mktemp /tmp/system_info_out_XXXXXX 2>/dev/null || echo /tmp/system_info_out.tmp)
TEMP_ERRORS=$(mktemp /tmp/system_info_err_XXXXXX 2>/dev/null || echo /tmp/system_info_err.tmp)

# Удаляем временные файлы при выходе
trap 'rm -f "$TEMP_OUTPUT" "$TEMP_ERRORS"' EXIT

# Обработка аргументов командной строки
while [[ $# -gt 0 ]]; do
    case $1 in
        -u|--users)
            SHOW_USERS=true
            EXECUTED=true
            shift
            ;;
        -p|--processes)
            SHOW_PROCESSES=true
            EXECUTED=true
            shift
            ;;
        -h|--help)
            show_help
            ;;
        -l|--log)
            if [[ -n "$2" && ! "$2" =~ ^- ]]; then
                LOG_FILE="$2"
                if ! check_path_access "$LOG_FILE" "file"; then
                    exit 1
                fi
                shift 2
            else
                echo "Ошибка: Опция $1 требует аргумент (путь к файлу)" >&2
                exit 1
            fi
            ;;
        -e|--errors)
            if [[ -n "$2" && ! "$2" =~ ^- ]]; then
                ERROR_FILE="$2"
                if ! check_path_access "$ERROR_FILE" "file"; then
                    exit 1
                fi
                shift 2
            else
                echo "Ошибка: Опция $1 требует аргумент (путь к файлу)" >&2
                exit 1
            fi
            ;;
        -*)
            echo "Ошибка: Неизвестная опция: $1" >&2
            echo "Используйте -h для справки." >&2
            exit 1
            ;;
        *)
            echo "Ошибка: Неожиданный аргумент: $1" >&2
            echo "Используйте -h для справки." >&2
            exit 1
            ;;
    esac
done

# Если ни одна команда не была указана
if [[ "$EXECUTED" == false ]]; then
    echo "Ошибка: Не указана команда для выполнения." >&2
    echo "Используйте -u для вывода пользователей или -p для процессов." >&2
    exit 1
fi

# Перенаправляем stderr в временный файл
exec 2>"$TEMP_ERRORS"

# Генерируем вывод
process_output > "$TEMP_OUTPUT"

# Обрабатываем вывод в зависимости от параметров
if [[ -n "$LOG_FILE" ]]; then
    # Сохраняем вывод в лог-файл
    if cp "$TEMP_OUTPUT" "$LOG_FILE" 2>/dev/null; then
        echo "Вывод сохранен в: $LOG_FILE" >&2
    else
        # Если не удалось скопировать, пытаемся записать напрямую
        if process_output > "$LOG_FILE" 2>/dev/null; then
            echo "Вывод сохранен в: $LOG_FILE" >&2
        else
            echo "Ошибка: Не удалось сохранить вывод в $LOG_FILE" >&2
            echo "Вывод на экран:" >&2
            cat "$TEMP_OUTPUT"
        fi
    fi
else
    # Выводим на экран
    cat "$TEMP_OUTPUT"
fi

# Обрабатываем ошибки
if [[ -n "$ERROR_FILE" ]]; then
    if [[ -s "$TEMP_ERRORS" ]]; then
        if cat "$TEMP_ERRORS" > "$ERROR_FILE" 2>/dev/null; then
            echo "Ошибки сохранены в: $ERROR_FILE" >&2
        else
            echo "Ошибка: Не удалось сохранить ошибки в $ERROR_FILE" >&2
        fi
    fi
elif [[ -s "$TEMP_ERRORS" ]]; then
    # Если есть ошибки и не указан файл для них, выводим на stderr
    echo "=== Сообщения об ошибках ===" >&2
    cat "$TEMP_ERRORS" >&2
fi

exit 0
